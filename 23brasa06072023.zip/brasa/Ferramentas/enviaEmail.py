
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from brasas import settings

class enviaEmail(EmailMultiAlternatives):
        """
            Emvia email.
            Exemplo:
                from Ferramentas.enviaEmail import enviaEmail
                e = enviaEmail(titulo="Eita nós",destino=['alessandropessoa1991@gmail.com'])
                e.contexto = {'conteudo':['quiehi','pastel','melancia'],'nome':'alessandro pessoa daconeilaç'}
                e.caminhoTemplate = 'Ordem/templates/email/testeEmail.html'
                e.enviar()
        """
        def __init__(self, titulo:str="", msg:str="", origem:str=settings.EMAIL_HOST_USER, destino:list=[]):
            
            super().__init__(subject=titulo, body=msg, from_email=origem, to=destino)

            self.caminhoTemplate = 'LLR/templates/email/email.html'
            self.contexto = dict()
            
            self.statusEnvioEmail = ""
            print("Iniciado processo de envio de email de compra")
            
        def enviar(self):
            self.html_body = render_to_string(f"{settings.BASE_DIR}/{self.caminhoTemplate}",context=self.contexto)
        
            enviaEmail.attach_alternative(self, content=self.html_body, mimetype="text/html")
            self.statusEnvioEmail = enviaEmail.send(self, fail_silently=False)
            print(f"Email de compra enviado a usuario criado, se {self.statusEnvioEmail} igual a 1 ")