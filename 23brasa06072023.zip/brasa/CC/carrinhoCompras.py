from decimal import Decimal
from django.conf import settings
from Home.models import Produto
from django.forms.models import model_to_dict


class CarrinhoCompras(object):
    
    def __init__(self,request) -> None:
        "Inicializa o carrinho"
       
        
        self.session    = request.session
        carro           = self.session.get(settings.CARRO_SESSAO_ID)
        if not carro:
            #Salva um carrinho vazio na sessao
            carro = self.session[settings.CARRO_SESSAO_ID]={}
            

        self.carro = carro
        
 
        

    def adicionar(self,produto,quantidade=1,sobrescreverQuantidade=True)-> None:
        """
            Adiciona um produto no carrinho de compras ou atualizar a sua quantidade.
            Os dados ficam salvos no navegador do cliente atraves dos cookies
            que são recuperados via request.session
        """
        produtoId  = str(produto.id)   

        if produtoId not in self.carro:      
            self.carro[produtoId] = {
                                    "quantidade":0,
                                    "preco":str(produto.preco), 
                                    } 
            
        if sobrescreverQuantidade:
            self.carro[produtoId]['quantidade'] = quantidade
        else:                                
            self.carro[produtoId]['quantidade'] += quantidade

        self.salvar()


    def remover(self,produtoId)-> None:
        """
            Remove um produto no carrinho de compras ou atualiza a sua quantidade
        """
        
        produtoId = str(produtoId.id)
        if produtoId in self.carro:
            del self.carro[produtoId]
            self.salvar()
     
     
        self.salvar()

    def __iter__(self):
        produtoLista =self.carro.keys()
        produtos = Produto.objects.filter(id__in=produtoLista)

        carro = self.carro.copy()

        for produto in produtos:
            carro[str(produto.id)]['produto'] = produto

        for item in carro.values():
            item['price'] = Decimal(item['preco'])
            item['totalPreco'] = int(Decimal(item['preco']))*item['quantidade']
            yield item
        



    def salvar(self)->None:
        """
            Marca a sessão como 'modificada' para garantir que ela seja salva
        """
        self.session.modified  = True
        

    def get_totalPrecos(self):
        """
            Calcula o valor total do itens do carrinho
        """
        return sum([Decimal(item['preco'])*item['quantidade'] for item in self.carro.values()])
    
    def limpaSessao(self):
        """
            Limpa sessão do carrinho
        """
        del self.session[settings.CARRO_SESSAO_ID]
        self.salvar()

    def __len__(self):
        return sum([item['quantidade'] for item in self.carro.values()])

