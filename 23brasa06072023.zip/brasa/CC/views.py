from django.shortcuts import render,redirect,get_object_or_404,HttpResponse
from django.views.decorators.http import require_POST
from Home.models import Produto
from .carrinhoCompras import CarrinhoCompras
from .forms import CarroAdicionaProdutosForm

@require_POST
def carroAdiciona(requests,produtoId):
    carro  = CarrinhoCompras(requests)
    produtoGet = get_object_or_404(Produto,id=produtoId)
        
    form = CarroAdicionaProdutosForm(requests.POST)
    if form.is_valid():
        cd = form.cleaned_data
        carro.adicionar(produtoGet, quantidade=cd['quantidade'], sobrescreverQuantidade=cd['sobrescrever'])
    #return redirect('carro:carroDetalhes')
    return redirect('home:produtosLista')

@require_POST
def carroRemove(requests,produtoId):
    ipCliente = capturaIp(requests)
    carro   = CarrinhoCompras(requests)
    produtoGet = get_object_or_404(Produto,id=produtoId)
    carro.remover(produtoGet)
    return redirect('carro:carroDetalhes')

def carrinhoDetalhes(requests):
    carro = CarrinhoCompras(requests)
    for item in carro:
        item['atualiza_quantidade_formulario'] = CarroAdicionaProdutosForm(initial={
            'quantidade':item['quantidade'],
            'sobrescrever':True
        })
   
    html        = 'cart.html'
    contexto    = {'carro':carro}
    return render(requests,html,contexto)



def capturaIp(arg=None):
    ipCliente = arg.META.get('HTTP_X_FORWARDED_FOR') 
    ipCliente = ipCliente.split(',')[0] if ipCliente else arg.META.get('REMOTE_ADDR') 
    return ipCliente