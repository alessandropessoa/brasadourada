from django import forms

"""
    Cria formulario que permite ao cliente escolher uma quantidade maxima 20 
"""

PRODUTO_QUANTIDADE_ESCOLHA  = [(i, str(i)) for i in range(1,21)]

class CarroAdicionaProdutosForm(forms.Form):
    quantidade      = forms.IntegerField(initial=1,min_value=1) 
    sobrescrever    = forms.BooleanField(required=False, initial=True, widget=forms.HiddenInput)
    class Media:
        css={
            "all":'css/forms.css'
        }

class CarroRemoveProdutosForm(forms.Form):
    quantidade      = forms.IntegerField(initial=1,min_value=1) 
    sobrescrever    = forms.BooleanField(required=False, initial=True, widget=forms.HiddenInput)