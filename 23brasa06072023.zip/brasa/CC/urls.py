from django.urls import path
from . import views

app_name='carro'

urlpatterns = [
    path('',views.carrinhoDetalhes,name='carroDetalhes'),
    path('adiciona/<int:produtoId>/',views.carroAdiciona,name='carroAdiciona'),
    path('remove/<int:produtoId>/',views.carroRemove,name='carroRemove'),
  
]
