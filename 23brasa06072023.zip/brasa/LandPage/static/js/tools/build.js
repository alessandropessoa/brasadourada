({
    baseUrl: "../",
    mainConfigFile: '../script.js',
    name: "script",
    out: "../script.min.js",
    findNestedDependencies: true,
    preserveLicenseComments: false
})