from django.forms import ModelForm, TextInput
from .models import Ordem

class OrdemCriacaoForm(ModelForm):
    class Meta:
        model  =Ordem
        fields =['primeiroNome','ultimoNome','tel','email','endereco','cep','cidade']
        widgets = {
            'primeiroNome': TextInput(attrs={
                'class': "form-control",
                'style': 'max-width: 300px;',
                'placeholder': 'Nome'
                }),

        }