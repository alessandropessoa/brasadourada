
from django.urls import path
from . import views

app_name= 'ordem'

urlpatterns = [
    path("criacao/",views.ordemCriacao,name="ordemCriacao"),
    path("conta/",views.ordemConta,name="ordemConta"),
  
]