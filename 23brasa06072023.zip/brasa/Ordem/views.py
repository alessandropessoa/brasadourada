from django.shortcuts import render,redirect,HttpResponse
from CC.carrinhoCompras import CarrinhoCompras
from .models import OrdemItem
from LLR.forms import PerfilForm,EnderecoForm
from .models import Ordem
from LLR.models import Perfil
from django.urls import reverse
from django.core.exceptions import ObjectDoesNotExist
from threading import Thread
from Ferramentas.enviaEmail import enviaEmail


def criaOrdem(carro,perfil,formEndereco,formUsuario): 
    ordem = Ordem(usuario=perfil)
    ordem.save()
    for item in carro:
        OrdemItem.objects.create(ordem      =ordem,\
                                produto     =item['produto'], 
                                preco       =item['preco'],
                                quantidade  =item['quantidade']
                                )
    carro.limpaSessao()
    return redirect(reverse('ordem:ordemConta'))


def ordemCriacao(requests):
    html    = "checkout.html"
    carro   = CarrinhoCompras(requests)
    form = {}
    formUsuario  =  PerfilForm()
    formEndereco = EnderecoForm()
    usuarioAtivo = requests.user if not "ANONYMOUSUSER" else ""
    contexto={}
    
    try:
        if requests.method == 'POST' :

            if requests.user.is_authenticated and not requests.user.is_staff:
                perfil = Perfil.objects.get(email=requests.user)
                criaOrdem(carro,perfil,formEndereco,formUsuario)

                print("calor de request.user.email --> ",requests.user.email)
                cliente = Perfil.objects.get(email=requests.user)
                ordemItem = [OrdemItem.objects.filter(ordem_id= id) for id in cliente.ordem.all()]    
                email = enviaEmail(titulo="Seu Pedido está a caminho!",destino=[f'{requests.user.email}'])
                email.contexto = {'conteudo':['quiehi','pastel','melancia'],'nome':'alessandro pessoa daconeilaç','ordemItem':ordemItem,'ordem':cliente.ordem.all()}
                email.caminhoTemplate = 'Ordem/templates/email/compraEmail.html'
                tarefa_enviaEmail = Thread(target=email.enviar)
                tarefa_enviaEmail.start()



            elif requests.user.is_authenticated and  requests.user.is_staff:
                perfil = Perfil.objects.get(primeiroNome=requests.user)
                criaOrdem(carro,perfil,formEndereco,formUsuario)

            
    except ObjectDoesNotExist:
        if requests.user.is_authenticated and  requests.user.is_staff:
            perfil = Perfil.objects.get(email=requests.user)
            criaOrdem(carro,perfil,formEndereco,formUsuario)
    finally:
        
        contexto =  {'carro':carro,'formUsuario':formUsuario,'formEndereco':formEndereco,'usuarioAtivo':usuarioAtivo,}     
        return render(requests,html,contexto)


def ordemConta(requests):
    html    = "pedidos.html"
    cliente ={}
    ordem={}
    contexto = {}
    try:
        cliente = Perfil.objects.get(email=requests.user)
    except ObjectDoesNotExist:
        return render(requests,html,contexto)
    
    if requests.user.is_authenticated :
        cliente =cliente
        ordemItem = [OrdemItem.objects.filter(ordem_id= id) for id in cliente.ordem.all()]
    else:         
        html =  HttpResponse("<h3>Vc ainda não possui items comprados</h3>")
        
    contexto = {
            'ordemItem':ordemItem,
            'ordem':cliente.ordem.all()
    }
    return render(requests,html,contexto)
