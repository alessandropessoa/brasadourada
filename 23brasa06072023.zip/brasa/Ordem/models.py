from django.db import models as bd
from Home.models import Produto
from LLR.models import Perfil


class Ordem(bd.Model):
    """
        Foi adotado modelo mutitabela com Usuario
    """
    usuario         = bd.ForeignKey(Perfil,on_delete=bd.SET_NULL,related_name=("ordem"),null=True)
    criado          = bd.DateTimeField( "Criado Em",auto_now_add=True)
    atualizado      = bd.DateTimeField("Atualizado Em",auto_now=True)
    statusPagamento = bd.BooleanField("Status de Pagamento",default=False)
    
    class Meta:
        get_latest_by = "criado"
        ordering =("-criado",)
        verbose_name = ("Pedido")
        verbose_name_plural = ("Pedidos")

    def __str__(self):
        return str(self.id)

    def getCustoTotal(self):
        return sum(item.getCusto() for item in self.items.all())


class OrdemItem(bd.Model):
    """
        Armazena o produto, a quantidade e o preço pago por item 
    """

    ordem           = bd.ForeignKey(Ordem, related_name=("items"), on_delete=bd.CASCADE)
    produto         = bd.ForeignKey(Produto, related_name=("ordemItems"), on_delete=bd.CASCADE)
    preco           = bd.DecimalField( max_digits=10, decimal_places=2)
    quantidade      = bd.PositiveIntegerField(default=1)


    def __str__(self):
        return str(self.id)
    
    def getCusto(self):
        return self.preco*self.quantidade
    
