from django.db import models as bd
from django.urls import reverse

class IntegerRangeField(bd.IntegerField):
    def __init__(self, verbose_name=None, name=None, min_value=None, max_value=None, **kwargs):
        self.min_value, self.max_value = min_value, max_value
        bd.IntegerField.__init__(self, verbose_name, name, **kwargs)
    def formfield(self, **kwargs):
        defaults = {'min_value': self.min_value, 'max_value':self.max_value}
        defaults.update(kwargs)
        return super(IntegerRangeField, self).formfield(**defaults)


class Categoria(bd.Model):
    nome = bd.CharField(max_length=200,db_index=True) #o db_index cria uma indexação tipo a do PrimaryKey pois essa coluna será muito usada como consulta
    slug = bd.SlugField(max_length=200,unique=True) # so pode haver um unico URL não pode haver dois slug iguais

    class Meta:
        ordering            = ('nome',)
        verbose_name        = 'Categoria'
        verbose_name_plural = 'Categorias'
    
    def __str__(self) -> str:
        return self.nome
    
    def get_absolut_url(self):
        return reverse('NSHome:produtosLista',
                       args=[self.slug]
                        )


class Produto(bd.Model):
    categoria       = bd.ForeignKey(Categoria,related_name='produtos',on_delete=bd.CASCADE)
    nome            = bd.CharField("Nome",max_length=200, db_index=True)
    slug            = bd.SlugField("Slug",max_length=200,db_index=True)
    imagem          = bd.ImageField("Imagem",upload_to='produtos/%Y/%m/%d/',blank=True)
    descricao       = bd.TextField("Descrição Curta",blank=True)
    descricaoLonga  = bd.TextField("Descrição Longa",blank=True)
    avaliacao       = IntegerRangeField("Avaliação",default=1,min_value=1,max_value=5)
    preco           = bd.FloatField("Preço",default=0)
    disponibilidade = bd.BooleanField("Disponibilidade em Estoque",default=True,help_text="Ao marcar, \
                                      o produto estará imediatamente disponivel no shop!")
    criado          = bd.DateField("Data Criação",auto_now_add=True)
    atualizado      = bd.DateField("Ultima atualização",auto_now=True)

    class Meta:
        ordering        = ('nome',)
        index_together  = (('id','slug'),)
    
    def __str__(self) -> str:
        return self.nome
    
    def get_absolut_url(self):
        return reverse('NSHome:produtoDetalhes',
                    args=[self.id,self.slug]
                    )