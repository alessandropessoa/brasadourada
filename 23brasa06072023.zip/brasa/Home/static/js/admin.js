
alert("Atenção ao inserir produtos, ao salvar e marcar como disponivel eles estarão visiveis para compra. ");