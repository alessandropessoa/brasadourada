from django.forms import ModelForm, TextInput
from .models import Perfil,Endereco

class PerfilForm(ModelForm):
    class Meta:
        model  = Perfil
        fields =['primeiroNome','ultimoNome','tel','email']
        widgets = {
            'primeiroNome': TextInput(attrs={
                'class': "form-control",
                'style': 'max-width: 300px;',
                'placeholder': 'Nome'
                }),
            'tel': TextInput(attrs={
                'placeholder': 'Se seu dd for diferente de 21, informe '
                }),

        }

class EnderecoForm(ModelForm):
    class Meta:
        model  = Endereco
        fields =['endereco','bairro','cep','cidade']
