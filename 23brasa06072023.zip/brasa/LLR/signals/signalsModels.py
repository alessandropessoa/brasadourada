from django.contrib.auth.models import User
from LLR.models import Perfil
from django.db.models.signals import post_save
from django.contrib.auth.hashers import make_password
from brasas import settings
from threading import Thread
from Ferramentas.criptografia import criptografia


def enviaEmail(nome,senha,login,email):
        from django.core.mail import EmailMultiAlternatives
        from django.template.loader import render_to_string

        titulo   = "Bem vindo a Brasa Dourada"
        contexto ={
             'nome':nome,
             'senha':senha,
             'login':login,
             'email':email,
        }
        message = EmailMultiAlternatives(
            subject=titulo,
            body="mail testing",
            from_email=settings.EMAIL_HOST_USER,
            to=[email],
        )
        html_body = render_to_string(f"{settings.BASE_DIR}/LLR/templates/email/email.html",context=contexto)
        message.attach_alternative(html_body, "text/html")
        status = message.send(fail_silently=False)
        print(f"Email enviado a usuario criado, se {status} igual a 1 ")



def criaUsuario(sender,instance,created,**kargs):
    #se um perfil foi criado, crie um usuario tbm
    if created:
        senhaH = criptografia(instance.primeiroNome)
        senha = make_password(senhaH.hexdigest())
        User.objects.create(username=instance.email,\
                            password=senha,\
                            email=instance.email,\
                            first_name=instance.primeiroNome,is_staff=False)
        print("Criado usuario para perfil. atraves do signals")
        print("senha --> ",senhaH.hexdigest())
        tarefa_enviaEmail = Thread(target=enviaEmail,args=(instance.primeiroNome,senhaH.hexdigest(),instance.email,instance.email))
        tarefa_enviaEmail.start()
    

post_save.connect(criaUsuario,sender=Perfil)
