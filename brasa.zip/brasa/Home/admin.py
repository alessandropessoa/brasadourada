from django.contrib import admin
from .models import Categoria,Produto

@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display        = ['nome','slug']
    prepopulated_fields = {'slug':('nome',)}


@admin.register(Produto)
class ProdutoAdmin(admin.ModelAdmin):
    list_display        = ['id','nome','slug','preco','disponibilidade','criado','atualizado']
    list_filter         = ['disponibilidade','criado','atualizado']
    list_editable       = ['preco','disponibilidade']
    prepopulated_fields = {'slug':('nome',)} 

    class Media:
        css = {
             "all": ["css/admin.css"],
         }
        js = ["js/admin.js"]



