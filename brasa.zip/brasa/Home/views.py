from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, HttpRequest
from .models import Categoria,Produto
from CC.forms import CarroAdicionaProdutosForm
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator


def HomeView(requests):
    html = 'index.html'
    categoria   = None
    ListaDeCategorias  = Categoria.objects.all()
    produtos    = Produto.objects.filter(disponibilidade=True)

    carro_produtos_form =  CarroAdicionaProdutosForm()

    contexto = {
        'produtos':produtos,
        'carro_produtos_form':carro_produtos_form,
    }
    return render(requests,html,contexto)

def maisProdutosView(requests):
    contexto = {}
    return render(requests,'maisProdutos.html',contexto)


def produtosLista(requests,categoria_slug=None):
    html = 'maisProdutos.html'
    categoria   = None
    ListaDeCategorias  = Categoria.objects.all()
    produtosF    = Produto.objects.filter(disponibilidade=True)
    paginacao = Paginator(produtosF,3) # o numero de objetos por pagina
    paginacaoNumero = requests.GET.get('pagina')
    produtos    = paginacao.get_page(paginacaoNumero)

    if categoria_slug:
        categoria       = get_object_or_404(Categoria,slug=categoria_slug)
        produtos        = produtosF.filter(categoria=categoria)
        paginacao       = Paginator(produtos,2) # o numero de objetos por pagina
        paginacaoNumero = requests.GET.get('pagina')
        produtos        = paginacao.get_page(paginacaoNumero)

    carro_produtos_form =  CarroAdicionaProdutosForm()

    contexto = {
        'categoria':categoria,
        'ListaDeCategorias':ListaDeCategorias,
        'produtos':produtos,
        'carro_produtos_form':carro_produtos_form,
    }
    
    return render(requests, html ,contexto)


def produtoDetalhes(requests,id,slug):
    html = 'detalhes.html'
    produtos    = get_object_or_404(Produto,
                                    id=id,
                                    slug=slug,
                                    disponibilidade=True,
                                    )
    carro_produtos_form =  CarroAdicionaProdutosForm(requests.POST)
    
    contexto = {
        'produtos':produtos,
        'carro_produtos_form':carro_produtos_form,
    }
    return render(requests, html, contexto)


@staff_member_required
def testeView(requests):
    n = requests.headers
    html="teste.html"
    contexto={}
    return render(requests,html,contexto)



