
from django.urls import path
from . import views

app_name= 'home'

urlpatterns = [
    path("teste/",views.testeView,name="teste"),
    path("",views.HomeView,name="homeView"),
    path("maisProdutos/",views.maisProdutosView,name="maisProdutosView"),
    path('shop/',views.produtosLista, name='produtosLista'),
    path('<slug:categoria_slug>/', views.produtosLista, name='produtosListaCategoria'),
    path('<int:id>/<slug:slug>/',views.produtoDetalhes, name='produtoDetalhes'),
    
    
  
]