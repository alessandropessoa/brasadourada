from .carrinhoCompras import CarrinhoCompras

def carroContexto(request):
    return {'carroContexto':CarrinhoCompras(request),}