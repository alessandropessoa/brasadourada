from django import template

register=  template.Library()

@register.filter('totalizador')
def totalizador(valor:object):
    totalPorOrdem       = []
    for ordem in valor:
        auxSoma= []         
        for ordemItem in ordem:
            auxSoma.append(ordemItem.getCusto())
        totalPorOrdem.append(sum(auxSoma))
    return totalPorOrdem


@register.filter('totalizadorGeral')
def totalizadorGeral(valor:object):
    totalTodosPedidos   = 0
    for ordem in valor:
        for ordemItem in ordem:
            totalTodosPedidos+=ordemItem.getCusto()
    return totalTodosPedidos

@register.filter('elementoLista')
def elementoLista(lista:list,elemento:int):
    return lista[elemento-1]