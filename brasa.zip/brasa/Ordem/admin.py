from django.contrib import admin
from .models import Ordem, OrdemItem


class OrdemItemInline(admin.TabularInline):
    model = OrdemItem
    raw_id_field = ['produto']
    extra=3


@admin.register(Ordem)
class OrdemAdmin(admin.ModelAdmin):
    list_display    = ['usuario','statusPagamento','criado','atualizado',]
    list_filter     = ['statusPagamento','criado','atualizado',]
    inlines          = [OrdemItemInline]
   



