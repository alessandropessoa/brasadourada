from brasas import settings

def criptografia(valor):
    import hashlib
    valorCriptografado = hashlib.sha256(f'{settings.TEMPERO_CRIPTOGRAFIA}{valor}{settings.TEMPERO_CRIPTOGRAFIA}'.encode())
    return valorCriptografado