
from django.contrib import admin
from django.urls import path
from django.contrib.auth import views as auth_views #modificando login django
from .views import loginCheckout,criaConta,loginPedidos,atualizacaoUsuario
app_name="llr"

urlpatterns = [
    path('', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('sair', auth_views.LogoutView.as_view(template_name='logout.html'), name='logout'),    
    path('loginChekout',loginCheckout,name="loginCheckout"),
    path('criaConta',criaConta,name="criaConta"),
    path('pedidos/',loginPedidos, name='pedidos'),
    path('atualizacao', atualizacaoUsuario, name='atualizacao'),
]
