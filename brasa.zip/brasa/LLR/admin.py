from django.contrib import admin
from .models import Perfil,Endereco

class EnderecoInline(admin.TabularInline):
    model = Endereco
    raw_id_field = ['endereco']
    extra=2


@admin.register(Perfil)
class PerfilAdmin(admin.ModelAdmin):
    exclude          = ['usuario']
    inlines          = [EnderecoInline]



