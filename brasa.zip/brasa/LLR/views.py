from django.shortcuts import render,redirect,HttpResponse
from django.urls import reverse
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from .models import Perfil,Endereco
from django.core.exceptions import ObjectDoesNotExist


def loginCheckout(requests):
    html=""
    contexto={}

    username = requests.POST["nome"]
    password = requests.POST["senha"]
    user = authenticate(requests, username=username, password=password)
    if user is not None:
        login(requests, user)
        # Redirect to a success page.
        return redirect(reverse('ordem:ordemCriacao'))
    else:
        html= "checkout/erroLoginCheckout.html"
        return render(requests,html,contexto)


def loginPedidos(requests):
    contexto={}
    if requests.POST:
        username = requests.POST["username"]
        password = requests.POST["password"]
        user = authenticate(requests, username=username, password=password)
        if user is not None:
            login(requests, user)
            return redirect(reverse('ordem:ordemConta'))
        else:
            html= "pedidos/erroLoginPedidos.html"
            return render(requests,html,contexto)
    else:
        html= "login.html"
        return render(requests,html,contexto)


def criaConta(requests):
    html        = ""
    contexto    = {}

    try:
        if requests.method == 'POST':
            form = dict(requests.POST)

            perfil = Perfil.objects.create(
                primeiroNome    = form['primeiroNome'][0], \
                ultimoNome      = form['ultimoNome'][0], \
                tel             = form['tel'][0], \
                email           = form['email'][0],\
                )

            endereco= Endereco.objects.create(
                usuario   = perfil, \
                endereco  = form['endereco'][0], \
                bairro    = form['bairro'][0], \
                cep       = form['cep'][0], \
                cidade    = form['cidade'][0], \
                )
        else:
            html =  HttpResponse("<h1>Senha ou usuairo invalido! Digite com calma.</h1>")
    except Exception as erro:
        if str(erro) =='UNIQUE constraint failed: auth_user.username':
            return HttpResponse("<p>Já existe esse usuario!</p>")
        else:
            print("deveria ter gerado erro!", erro)
    finally: 
        return redirect(reverse('NSOrdem:ordemCriacao',kwargs=contexto))



def atualizacaoUsuario(requests):
    html        = 'perfil.html'
    contexto    = {}
    
    
    try:
        perfil  = Perfil.objects.get(email=requests.user)
        user    = User.objects.get(email=requests.user)
        contexto={'perfil':perfil}
        if requests.POST:
            senha = requests.POST.get('senha')
            user.set_password(senha)
            user.save()
    except ObjectDoesNotExist:
        print("Perfil nao existe")
        return HttpResponse("<p>Há algo de errado. Perfil não existe</p>")
    return render(requests,html,contexto)