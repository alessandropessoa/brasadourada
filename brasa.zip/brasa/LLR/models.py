from django.db import models as bd
from django.contrib.auth.models import User



class Perfil(bd.Model):
    usuario         = bd.OneToOneField(User,related_name="perfil",on_delete=bd.CASCADE,null=True)
    primeiroNome    = bd.CharField("Primeiro Nome",max_length=50)
    ultimoNome      = bd.CharField("Ultimo Nome",max_length=50)
    tel             = bd.CharField("Tel",max_length=15)
    email           = bd.EmailField("Email")
    criado          = bd.DateField( "Criado Em",auto_now_add=True)
    atualizado      = bd.DateField("Atualizado Em",auto_now=True)
    class Meta:
        get_latest_by = "criado"
        ordering =("primeiroNome",)
        verbose_name = ("Perfil")
        verbose_name_plural = ("Perfis")

    def __str__(self):
        return self.primeiroNome


class Endereco(bd.Model):
    usuario         = bd.ForeignKey(Perfil,related_name=("enderecos"), on_delete=bd.CASCADE,null=True)
    endereco        = bd.CharField("Endereço",max_length=250)
    bairro          = bd.CharField("Bairro",max_length=100)
    cep             = bd.CharField("Cep",max_length=20)
    cidade          = bd.CharField("Cidade",max_length=100)
    enderecoEntrega= bd.BooleanField("Marcar como endereço de entrega",default=False,\
                                     help_text="Marque essa opção somente \
                                     se for o endereço de entrega")
    atualizado      = bd.DateField("Atualizado Em",auto_now=True)



